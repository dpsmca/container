CREATE TABLE  XCalibur_DB_Version
(
  date_time  	DATE,
  Major_Version	NUMBER(4),
  Minor_Version	NUMBER(4),
  computer_name	VARCHAR2(128),
  comments	VARCHAR2(2048)
)
/
CREATE TABLE  Application_type
(
  application_type_id	NUMBER(15),
  application_name	VARCHAR2(128),
  user_label_1		VARCHAR2(255),
  user_label_2		VARCHAR2(255),
  user_label_3		VARCHAR2(255),
  user_label_4		VARCHAR2(255),
  user_label_5		VARCHAR2(255),
  CONSTRAINT pk_application_type  PRIMARY KEY (application_type_id)
)
/
CREATE TABLE Computer_info
( 
  computer_info_id		NUMBER(15),
  computer_name			VARCHAR2(128) UNIQUE,
  CONSTRAINT pk_computer_info PRIMARY KEY (computer_info_id)
)
/
CREATE TABLE  dataset_identifier 
(
  dataset_identifier_id 		NUMBER(15),
  dataset_name		VARCHAR2(255),
  CONSTRAINT pk_dataset_identifier_id PRIMARY KEY (dataset_identifier_id)
)
/
CREATE TABLE user_info
( 
  user_info_id		NUMBER(15),
  user_name		VARCHAR2(128),
  full_name		VARCHAR2(128),
  CONSTRAINT pk_user_information  PRIMARY KEY (user_info_id)
)
/
CREATE TABLE Inst_info
( 
  inst_info_id		NUMBER(15),
  inst_name		VARCHAR2(128) UNIQUE,
  CONSTRAINT pk_inst_info PRIMARY KEY (inst_info_id)
)
/
CREATE TABLE Event_log
(
  event_log_id 			  NUMBER(15),
  application_type_id                  NUMBER(15),
  computer_info_id                NUMBER(15),
  dataset_identifier_id           NUMBER(15),
  user_info_id    	          NUMBER(15), 
  date_Time  	                  DATE,
  instance_name                   VARCHAR2(128),
  event       		          VARCHAR2(255),
  response		          VARCHAR2(255),
  comments     		          VARCHAR2(512),
  over_flow			  VARCHAR2(1024),
  CONSTRAINT pk_event_log         PRIMARY KEY (event_log_id),
  CONSTRAINT fk_audit_computer    FOREIGN KEY (computer_info_id)    REFERENCES computer_info(computer_info_id),
  CONSTRAINT fk_audit_user        FOREIGN KEY (user_info_id)        REFERENCES user_info(user_info_id),
  CONSTRAINT fk_audit_application FOREIGN KEY (application_type_id) REFERENCES application_type (application_type_id),
  CONSTRAINT fk_audit_dataset     FOREIGN KEY (dataset_identifier_id)     REFERENCES dataset_identifier(dataset_identifier_id)
)
/
--TABLESPACE Data1 STORAGE (INITIAL  512   NEXT  512  MINEXTENTS 1 MAXEXTENTS  UNLIMITED )   
CREATE TABLE  Xcalibur_files
(
  file_id 		NUMBER(15),
  computer_info_id  	NUMBER(15),
  file_name		VARCHAR2(255),
  path	 		VARCHAR2(255),  
  file_date_time        DATE,
  user_info_id          NUMBER(15),
  application_type_id        NUMBER(15),
  dataset_identifier_id            NUMBER(15),
  file_ref_number	VARCHAR2(20),
  CONSTRAINT pk_xcalibur_files            PRIMARY KEY (file_id),
  CONSTRAINT fk_xacl_files_computer_info  FOREIGN KEY (computer_info_id) REFERENCES computer_info(computer_info_id),
  CONSTRAINT fk_xacl_files_user           FOREIGN KEY (user_info_id)        REFERENCES user_info(user_info_id),
  CONSTRAINT fk_xacl_files_application    FOREIGN KEY (application_type_id) REFERENCES application_type (application_type_id),
  CONSTRAINT fk_xacl_files_dataset        FOREIGN KEY (dataset_identifier_id)     REFERENCES dataset_identifier(dataset_identifier_id)  
)
/   
CREATE TABLE File_tracking_log
(
  file_tracking_log_id		NUMBER(15),
  date_time                     Date,
  computer_info_id              NUMBER(15),
  user_info_id                  NUMBER(15),
  application_type_id           NUMBER(15),
  dataset_identifier_id         NUMBER(15),
  file_id                       NUMBER(15),
  crc 				NUMBER(15),
  file_status                   NUMBER(15),
  instance_name                 VARCHAR2(128), 
  comments			VARCHAR2(512),   
  over_flow			VARCHAR2(1024),
  CONSTRAINT pk_file_tracking_log        PRIMARY KEY (file_tracking_log_id),
  CONSTRAINT fk_file_track_computer      FOREIGN KEY (computer_info_id)         REFERENCES computer_info(computer_info_id),  
  CONSTRAINT fk_file_track_user          FOREIGN KEY (user_info_id)             REFERENCES user_info(user_info_id),   
  CONSTRAINT fk_file_track_Application   FOREIGN KEY (application_type_id)      REFERENCES Application_type(application_type_id),   
  CONSTRAINT fk_file_track_Dataset       FOREIGN KEY (dataset_identifier_id)    REFERENCES dataset_identifier(dataset_identifier_id),  
  CONSTRAINT fk_file_tracking_xcal_file  FOREIGN KEY (file_id)             REFERENCES xcalibur_files(file_id)
)   
/
--TABLESPACE Data1 STORAGE (INITIAL  512   NEXT  512  MINEXTENTS 1 MAXEXTENTS  UNLIMITED 
CREATE TABLE History_log
(
  history_log_id        NUMBER(15),
  computer_info_id	NUMBER(15),
  user_info_id    	NUMBER(15), 
  application_type_id 	NUMBER(15),
  dataset_identifier_id NUMBER(15),
  file_id               NUMBER(15),
  date_Time  		DATE, 
  old_row    		VARCHAR2(128),
  new_row    		VARCHAR2(128),
  instance_name         VARCHAR2(128),
  change_type  		VARCHAR2(128),  
  item_changed		VARCHAR2(255),  
  old_value 		VARCHAR2(255),
  new_value      	VARCHAR2(255),
  user_data_1    	VARCHAR2(255),
  user_data_2    	VARCHAR2(255),
  user_data_3    	VARCHAR2(255),
  user_data_4    	VARCHAR2(255),
  user_data_5    	VARCHAR2(255),
  over_flow		VARCHAR2(1024),
  CONSTRAINT pk_history                PRIMARY KEY (history_log_id),
  CONSTRAINT fk_history_computer_info  FOREIGN KEY (computer_info_id)    	REFERENCES computer_info(computer_info_id),
  CONSTRAINT fk_history_user           FOREIGN KEY (user_info_id)        	REFERENCES user_info(user_info_id),
  CONSTRAINT fk_history_application    FOREIGN KEY (application_type_id) 	REFERENCES application_type(application_type_id),
  CONSTRAINT fk_history_dataset        FOREIGN KEY (dataset_identifier_id)     	REFERENCES dataset_identifier(dataset_identifier_id),
  CONSTRAINT fk_history_xcal_file      FOREIGN KEY (file_id)  		       	REFERENCES xcalibur_files(file_id)
)
/
--TABLESPACE Data1 STORAGE (INITIAL  512   NEXT  512  MINEXTENTS 1 MAXEXTENTS  UNLIMITED ) 
CREATE TABLE Inst_error_log
(
  inst_error_log_id		  NUMBER(15),
  application_type_id             NUMBER(15),
  computer_info_id                NUMBER(15),
  dataset_identifier_id           NUMBER(15),
  user_info_id    	          NUMBER(15), 
  date_Time  	                  DATE,
  instance_name                   VARCHAR2(128),
  inst_error_code		  NUMBER(15), 
  inst_error_severity		  NUMBER(15), 
  inst_error_string		  VARCHAR2(512),
  acquire_mode			  NUMBER(15), 
  file_id			  NUMBER(15), 
  time_offset			  NUMBER(15), 
  inst_info_id			  NUMBER(15), 
  event       		          VARCHAR2(255),				
  response		          VARCHAR2(255),
  comments     		          VARCHAR2(512),
  over_flow			  VARCHAR2(1024),
  CONSTRAINT pk_inst_error_log         PRIMARY KEY (inst_error_log_id),
  CONSTRAINT fk_inst_error_computer    FOREIGN KEY (computer_info_id)    	REFERENCES computer_info(computer_info_id),
  CONSTRAINT fk_inst_error_user        FOREIGN KEY (user_info_id)        	REFERENCES user_info(user_info_id),
  CONSTRAINT fk_inst_error_application FOREIGN KEY (application_type_id) 	REFERENCES application_type (application_type_id),
  CONSTRAINT fk_inst_error_dataset     FOREIGN KEY (dataset_identifier_id)   	REFERENCES dataset_identifier(dataset_identifier_id),
  CONSTRAINT fk_inst_error_xcal_file   FOREIGN KEY (file_id)  			REFERENCES xcalibur_files(file_id),
  CONSTRAINT fk_inst_error_inst_info   FOREIGN KEY (inst_info_id)  		REFERENCES Inst_info(inst_info_id)
)
/
--Automatic generation of Computere_id Oracle keeps track of the values used.

CREATE SEQUENCE application_type_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
CREATE SEQUENCE computer_info_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
CREATE SEQUENCE inst_error_log_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
CREATE SEQUENCE inst_info_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
--Automatic generation of dataset_identifier_id Oracle keeps track of the values used.
CREATE SEQUENCE dataset_identifier_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
--Automatic generation of event_log_id Oracle keeps track of the values used.
CREATE SEQUENCE event_log_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
--Automatic generation of event_log_id Oracle keeps track of the values used.
CREATE SEQUENCE history_log_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
--Automatic generation of user_info_id Oracle keeps track of the values used.
CREATE SEQUENCE user_info_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
--Automatic generation of Rawfile_id Oracle keeps track of the values used.
CREATE SEQUENCE xcalibur_files_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
CREATE SEQUENCE  file_tracking_log_id_seq
  minvalue 1000
  increment by 1
  start with 1000
/
--EXIT